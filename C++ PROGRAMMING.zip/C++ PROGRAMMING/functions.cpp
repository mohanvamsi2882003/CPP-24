#include<iostream>
using namespace std;

class first
{
  private:
  	static int b;
  	int a;
  public:
  	fun()
  	    {
  		a = 8;
  		cout<<a<<" "<<b<<" ";
  		a++;
  		b++;
	  }
};
int first::b=90;

main()
{
	first obj,obj2,obj3;
	obj.fun();
	obj2.fun();
	obj3.fun();
}