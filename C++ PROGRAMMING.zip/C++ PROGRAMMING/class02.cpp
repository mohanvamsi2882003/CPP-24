#include<iostream>
using namespace std;

class rectangle
{
	public:
		int l;
		int b;
		int area;
	public:
		Area1()
		{
			l=10;
			b=10;
		   }
		Area2()
		{
			area = l*b;
			cout<<area;
		   }
};

main()
{
rectangle obj;
obj.Area1();
obj.Area2();

}