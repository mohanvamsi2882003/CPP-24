#include<iostream>
using namespace std;

class result
{
	private:
		int s1,s2,avg;
	public:
		getdata()
		{
			cout<<"hi"<<endl;
		}
};
main()
{
	result obj[20];
	int i;
	for(i=0;i<20;i++)
	{
		obj[i].getdata();
	}
}