#include<iostream>
using namespace std;
class first
{
	public:
		int x,y;
		int a,b;
	private:
		fun()
		{
			x=5;
			y=10;
			a=9;
			cout<<y;
		}
};
main()
{
	class first student;
	first.fun();
}