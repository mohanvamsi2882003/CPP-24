#include<iostream>
using namespace std;

class first
{
  private:
  	static int score;
  	int a;
  	int player[10];
  public:
  	fun()
  	    {
  		
	  }
	fun01()
	{
		
	}
};
int first::score;

main()
{
	first obj,obj2,obj3;
	obj.fun();
}