#include<iostream>
using namespace std;

main()
{
	int sum=0,i;
	
	for(i=i;i<18;i++)
	{
		cout<<i<<"\n";
		sum=sum+1;
	}
	cout<<sum;
}