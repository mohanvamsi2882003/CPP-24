#include<iostream>
using namespace std;

struct student
{
	int id;
	int age;
	char name[20];
};

main()
{
	struct student s1{1,21,"vamsi"};
	cout<<s1.name;
	cout<<s1.id;
	
}