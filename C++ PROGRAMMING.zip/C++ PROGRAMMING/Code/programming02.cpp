#include<iostream>
using namespace std;

main()
{
	int n=1;
	
	while(n<10)
	{
		cout<<n;
		n++;
		
	}

}