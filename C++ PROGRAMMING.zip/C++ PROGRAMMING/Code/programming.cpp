//check whether they are eligible to vote or not
#include<iostream>
using namespace std;
main()
{
	int age;
	cout<<"Enter your age for eligibility";
	cin>>age;
	
	if(age>18)
	{
		cout<<"you are eligible";
	}
	elseif(age=18)
	{
		cout<<"you are eligible";
	}
	else
	{
		cout<<"you are not eligible";
	}
}