#include <iostream>
using namespace std;

int main() {
    //Write your code here
    string name;
    int age;
    getline(cin,name);
    cin>>age;
    cout<<"The name of the person is"<<" "<<name<<" "<<"and the age is"<<" "<<age;
    return 0;
}