//recursion
#include<iostream>
using namespace std;

main()
{
	int rect(int);
	rect(5);
} 
int rect(int x)
{
	int b;
	if(x<1)
	{
		return(1);
	}
	else
	{
		b = rect(x-1);
		return(b);
	}

}
