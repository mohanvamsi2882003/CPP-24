#include<iostream>
using namespace std;
main()
{
	void fun(int x,int y);
	fun(9,10);	
}
void fun(int a,int b)
{
	int z; 
	z = a+b;
	cout<<z;
}
