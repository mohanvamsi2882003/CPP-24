#include <iostream>
using namespace std;

union emp
{
	int id;
	char name[20];
	float salary;
};

union dept
{
	int dn;
	 
};
int a;
main()
{
      cout<<sizeof(a);
		/*struct dept d1;
	cin>>d1.dn;
	cin>>d1.e1.salary;
	cout<<d1.dn;
	cout<<d1.e1.salary;*/
}