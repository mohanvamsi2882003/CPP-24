#include<iostream>
using namespace std;

main()
{
	void sum01(int x,int y);
	sum01(1,2);
		void sum01(float x,float y);
		sum01(9.5,9.6);
			void sum01(double x,int z,double y);
		sum01(9.5,5,9.6);
}
void sum01(int x,int y)
{
	cout<<x<<y<<endl;
}
void sum01(float a,float b)
{
	cout<<a<<b<<endl;
}
void sum01(double a,int z,double b)
{
	cout<<a<<" "<<z<<" "<<b<<endl;
}