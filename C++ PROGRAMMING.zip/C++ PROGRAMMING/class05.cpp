#include<iostream>
using namespace std;

class subject
{
	private:
		int a,b;
		float average;
	public:
	void fun01();
	void fun02();
};

void subject::fun01()
{
		int a,b;
		float average;
}
void subject::fun02()
{
	
			average = (a+b)/2;
			cout<<average;
}
//:: scope resolution operator
main()
{
	subject obj;
	obj.fun01();
	obj.fun02();
}