#include<iostream>
using namespace std;

main()
{
	int a=9,b=2;
	void swap(int, int);
	cout<<a<<b<<endl;
	swap(a,b);
	cout<<a<<b<<endl;
}

void swap(int x,int y)
{
	int z;
	z = x;
	y = x;
	x = z;
	cout<<x<<y<<endl;
}