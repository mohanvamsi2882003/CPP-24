#include<iostream>
using namespace std;
main()
{
	
	int fun();
cout<<	fun();	

}
int fun()
{
	int a=2,b=6,z; 
	z = a+b;
	return z;
}
