#include<iostream>
using namespace std;

class fb
{
	private:
		int n1,n2,n3,i,number;
    public:
    	fun1()
    	{
    		n1 = 0;
    		n2 = 1;
		}
		
		fun2()
		{
		    for (i=2;i<number;i++);
			{
				n3 = n1+n2;
				cout<<n3<<" ";
				n1 = n2;
				n2 = n3;
				}	
		}	
};

main()
{
	fb obj;
	obj.fun1();
	obj.fun2();	
}