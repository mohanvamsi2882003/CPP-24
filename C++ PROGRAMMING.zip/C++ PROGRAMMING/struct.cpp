#include <iostream>
using namespace std;

struct emp
{
	int id;
	char name[20];
	float salary;
};

main()
{
	struct emp e1 = { 1,"abc", 3000};
	cout<< e1.id<<"  "<<e1.name<<"  "<<e1.salary;
}