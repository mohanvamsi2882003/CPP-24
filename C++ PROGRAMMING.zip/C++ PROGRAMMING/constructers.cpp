#include<iostream>
using namespace std;

class rectangle
{
    private:
	       int l,b,a;
	public:
	        rectangle(int x=4,int y=5)
	        {
	            l =x;
	            b =y;
	            cout<<"i am a default constructer"<<endl;
	                   }
	        fun()
	        {
	        	a = l*b;
		        cout<<a<<endl;
		               }	
};
main()
{
 rectangle obj;
 obj.fun();
}