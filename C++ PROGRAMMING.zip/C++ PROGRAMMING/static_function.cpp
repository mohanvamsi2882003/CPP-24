#include<iostream>
using namespace std;

class first
{
  private:
  	static int b;
  	int a;
  public:
  	 fun()
  	    {
  		a = 8;
  		cout<<a<<" "<<b<<" ";
  		a++;
  		b++;
	  }
   static fun01()
	{
		cout<<b;
	}
};
int first::b=90;

main()
{
	first::fun();
}