#include<iostream>
using namespace std;

class subject
{
	private:
		int a,b;
		float average;
	public:
		fun01()
		{
			cin>>a;
			cin>>b;
		}
		fun02()
		{
			average = (a+b)/2;
			cout<<average;
		}
};
main()
{
	subject obj01;
	obj01.fun01();
	obj01.fun02();
}