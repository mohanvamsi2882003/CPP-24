//Using Friend function
#include<iostream>
using namespace std;

class rectangle
{
	private:
		int area,l,b;
	public:
		values()
		{
			l = 10;
			b =20;
		}
		friend int a(rectangle r);
};

int a(rectangle r)
{
	r.area = r.l*r.b;
    cout<<r.area<<endl;
}
main()
{
	rectangle obj;
	obj.values();
	a(obj);
}