#include<iostream>
using namespace std;
main()
{

enum day{s='a',m ,t ,w };
day day1, day2;
day1 = s;
day2 = m;

cout<<s<<endl;
cout<<m;
}