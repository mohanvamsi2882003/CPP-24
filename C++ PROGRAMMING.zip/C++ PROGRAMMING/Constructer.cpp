#include<iostream>
using namespace std;

class rectangle
{
    private:
	       int l,b,a;
	public:
	        rectangle()
	        {
	            l =10;
	            b =50;
	            cout<<"i am a default constructer"<<endl;
	                   }
	        fun()
	        {
	        	a = l*b;
		        cout<<a<<endl;
		               }	
		     rectangle(int x, int y)
	        {
	            l =10;
	            b =50;
	            cout<<"i am a parameterised constructer"<<endl;
	                   }
	         rectangle(rectangle &obj)
	        {
	            l =obj.l;
	            b =obj.b;
	            cout<<"i am a copy constructer"<<endl;
	                   }
	         rectangle(float w,float g)
	        {
	            l =w;
	            b =g;
	            cout<<"comes with single parameterr"<<endl;
	                   }
};
main()
{
	rectangle obj,obj1(8,7);// calling the parameterised constructer
	obj.fun();
	rectangle obj3(obj);// copy constructer
	obj3.fun();
	rectangle obj4 = obj;// calling copy contructer another way
	obj4.fun();
	rectangle obj7(9.0,10.1);
}