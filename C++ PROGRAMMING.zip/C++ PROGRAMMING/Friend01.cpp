//friend function using two classes
#include<iostream>
using namespace std;

class brother
{
	private:
		int salary,total,bonus;
	public:
		get()
		{
		salary = 50000;
		bonus = 20000;
		total = salary + bonus;
		}
		friend class sister;
};

class sister
{
	private:
		int savings,previous;
	public:
		amount(brother ob)
		{
			previous = 10000;
			savings = previous +ob.total;
			cout<<savings;
		}	
};

main()
{
	brother objb;
	sister objs;
	objb.get();
	objs.amount(objb);
	
}