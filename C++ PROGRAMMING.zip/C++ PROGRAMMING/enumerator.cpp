#include<iostream>
using namespace std;

main(){

enum days{s,m,t,w};
	
  days day1, day2;
  day1 = s;
  cout<<day1;
}