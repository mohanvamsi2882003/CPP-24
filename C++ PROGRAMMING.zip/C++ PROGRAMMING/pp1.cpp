include<iostream>
using namespace std;

main()
{
enum {R='a', B=10, G, Y};
cout<<R;
}