#include<iostream>
using namespace std;
main()
{
	void fun();
	fun();	
}
void fun()
{
	cout<<"hi"<<endl;
	int x =10, y =11;
	int z;
	z = x+y;
	cout<<z;
	return;// return is used to return to the main 
}
