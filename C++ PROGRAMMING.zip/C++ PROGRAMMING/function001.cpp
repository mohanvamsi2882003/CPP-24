#include<iostream>
using namespace std;

main()
{
	void rect(int);
	int n=4;
	int fact;
	fact = rect(n);
	
} 

void rect(int x)
{
	cout<<"hi";
}