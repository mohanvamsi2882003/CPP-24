#include<iostream>
using namespace std;

main()
{
	void sum01(int x = 9,int y =20);
	sum01(8);
	cout<<x<<y<<endl;
	
}
void sum01(intx,inty)
{
	cout<<x<<y<<endl;
	int a;
	a = x*y;
	cout<<a;
}