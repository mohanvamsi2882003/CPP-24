#include<iostream>
using namespace std;

struct student 
{
int age;
double cgpa;	
};

union employee
{
int age;
double cgpa;	
};

main()
{
	struct student s1;
	cout<<sizeof(s1)<<endl; // endl is used to terminate the line

    union employee e1;
    cout<<sizeof(e1);
}